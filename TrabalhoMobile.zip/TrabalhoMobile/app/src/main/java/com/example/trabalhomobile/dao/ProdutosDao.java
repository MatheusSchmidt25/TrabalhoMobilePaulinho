package com.example.trabalhomobile.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.trabalhomobile.helper.SQLiteDataHelper;
import com.example.trabalhomobile.model.Produtos;
import com.example.trabalhomobile.model.Vendedor;
import com.example.trabalhomobile.view.PedidosActivity;

import java.util.ArrayList;

public class ProdutosDao implements IGenericDao<Produtos> {
    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase baseDados;
    private String[]colunas = {"MARCA","MODELO", "VALOR"};
    private String tabela = "PRODUTOS";
    private Context context;

    private static ProdutosDao instancia;

    public static ProdutosDao getInstancia(Context context){
        if (instancia == null){
            return instancia = new ProdutosDao(context);
        }else{
            return  instancia;
        }
    }

    private ProdutosDao(Context context){
        this.context = context;

        openHelper = new SQLiteDataHelper(this.context, "LOJA_BD", null, 1);
        baseDados = openHelper.getWritableDatabase();

    }
    @Override
    public long insert(Produtos obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getMarca());
            valores.put(colunas[1], obj.getModelo());
            valores.put(colunas[2], obj.getValor());
            return baseDados.insert(tabela, null, valores);
        }catch (SQLException ex){
            Log.e("PRODUTOS", "ERRO: ProdutosDao.insert() "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long update(Produtos obj) {
        return 0;
    }

    @Override
    public long delete(Produtos obj) {
        return 0;
    }

    @Override
    public ArrayList<Produtos> getAll() {

        ArrayList<Produtos> lista = new ArrayList<>();
        try{
            Cursor cursor = baseDados.query(tabela, colunas, null,null,
                    null,null, colunas[0]+" desc");

            if(cursor.moveToFirst()){
                do{
                    Produtos produtos = new Produtos();
                    produtos.setMarca(cursor.getString(0));
                    produtos.setModelo(cursor.getString(1));
                    produtos.setValor(cursor.getDouble(2));


                    lista.add(produtos);

                }while (cursor.moveToNext());
            }

        }catch (SQLException ex){
            Log.e("VENDAS", "ERRO: VendedorDao.GetAll() "+ex.getMessage());
        }
        return lista;

    }

    @Override
    public Produtos getById(int id) {
        return null;
    }
    public ArrayList<String> getModelosProdutos() {
        ArrayList<String> modelos = new ArrayList<>();
        try {
            Cursor cursor = baseDados.query(tabela, colunas, null, null,
                    null, null, colunas[0] + " desc");

            if (cursor.moveToFirst()) {
                do {
                    String modelo = cursor.getString(1); // Obtenha o modelo do cursor
                    modelos.add(modelo);

                } while (cursor.moveToNext());
            }

        } catch (SQLException ex) {
            Log.e("PRODUTOS", "ERRO: ProdutosDao.getModelosProdutos() " + ex.getMessage());
        }
        return modelos;
    }
}
