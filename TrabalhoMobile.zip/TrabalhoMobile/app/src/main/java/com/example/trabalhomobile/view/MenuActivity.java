package com.example.trabalhomobile.view;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.trabalhomobile.MainActivity;
import com.example.trabalhomobile.R;
import com.example.trabalhomobile.dao.PedidoDao;
import com.example.trabalhomobile.model.Pedido;
import com.example.trabalhomobile.model.Vendedor;

import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity {

    private Button btComprar;
    private Button btVoltar;
    private String nomeVendedor;
    private Button btNotas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btComprar = findViewById(R.id.btComprar);
        btVoltar = findViewById(R.id.btVoltar);
        btNotas = findViewById(R.id.btNotas);
        nomeVendedor = getIntent().getStringExtra("NOME_VENDEDOR");

        btNotas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirActivity(NotasActivity.class);
            }
        });



        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                voltar();
            }
        });

        btComprar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirActivity(PedidosActivity.class);
            }
        });
    }



    private void voltar() {
        finish();
    }

    private void abrirActivity(Class<?> activity) {
        Intent intent = new Intent(MenuActivity.this, activity);
        startActivity(intent);
    }



}

