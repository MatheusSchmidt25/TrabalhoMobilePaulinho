package com.example.trabalhomobile;

public class Global {
    public static String nomeVendedor;
}
