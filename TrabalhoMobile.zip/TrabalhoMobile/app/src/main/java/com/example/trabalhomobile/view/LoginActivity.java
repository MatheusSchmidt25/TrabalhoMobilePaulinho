package com.example.trabalhomobile.view;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.trabalhomobile.Global;
import com.example.trabalhomobile.MainActivity;
import com.example.trabalhomobile.R;
import com.example.trabalhomobile.controller.VendedorController;
import com.example.trabalhomobile.dao.VendedorDao;
import com.example.trabalhomobile.model.Vendedor;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    private EditText etLogin;
    private EditText etSenha;
    private Button btEntrar;
    private Button btCadastrar;
    private AlertDialog dialog;
    private VendedorController controller;
    private View viewAlert;
    private EditText edCadastroNome;
    private EditText edCadastroCpf;
    private EditText edCadastroLogin;
    private EditText edCadastroSenha;
    private String vendedorSelecioonado;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        controller = new VendedorController(this);


        etLogin = findViewById(R.id.etLogin);
        etSenha = findViewById(R.id.etSenha);

        btEntrar = findViewById(R.id.btEntrar);
        btCadastrar = findViewById(R.id.btCadastrar);

        btEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                entrar();
            }
        });

        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadastrar();
            }
        });

    }

    private void entrar() {
        ArrayList<Vendedor> listaVendedores = VendedorDao.getInstancia(this).getAll();


        String login = etLogin.getText().toString();
        String senha = etSenha.getText().toString();

        if(login.equals("") || login.isEmpty() || senha.equals("") || senha.isEmpty()){
            Toast.makeText(LoginActivity.this, "Preencha todos os campos! ", Toast.LENGTH_SHORT).show();
        }


        for (Vendedor vendedor : listaVendedores){
            if (vendedor.getLogin().equals(login) && vendedor.getSenha().equals(senha)){
                vendedor.setNomeLogin(vendedor.getNome());
                Global.nomeVendedor = vendedor.getNome();
                abrirActivity(MenuActivity.class);
            }
        }
    }

    private void cadastrar() {

        viewAlert = getLayoutInflater()
                .inflate(R.layout.dialog_cadastro_vendedor, null);

        edCadastroNome = viewAlert.findViewById(R.id.edCadastroNome);
        edCadastroCpf = viewAlert.findViewById(R.id.edCadastroCpf);
        edCadastroLogin = viewAlert.findViewById(R.id.edCadastroLogin);
        edCadastroSenha = viewAlert.findViewById(R.id.edCadastroSenha);

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("CADASTRO VENDEDOR");
        builder.setView(viewAlert);
        builder.setCancelable(false);

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialog.dismiss();
            }
        });

        builder.setPositiveButton("Salvar", null);
        dialog = builder.create();

        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                Button bt = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                bt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        salvarDados();
                    }
                });
            }
        });
        dialog.show();
    }

    private void salvarDados() {
        String retorno = controller.salvarVendedor(edCadastroNome.getText().toString(),
                edCadastroCpf.getText().toString(),
                edCadastroLogin.getText().toString(),
                edCadastroSenha.getText().toString());
        if (retorno != null){
            if (retorno.contains("NOME")){
                edCadastroNome.setError(retorno);
                edCadastroNome.requestFocus();
            }
            if (retorno.contains("CPF")){
                edCadastroCpf.setError(retorno);
                edCadastroCpf.requestFocus();
            }
            if (retorno.contains("LOGIN")){
                edCadastroLogin.setError(retorno);
                edCadastroLogin.requestFocus();
            }
            if (retorno.contains("SENHA")){
                edCadastroSenha.setError(retorno);
                edCadastroSenha.requestFocus();
            }
        }else{
            Toast.makeText(this,"Vendedor cadastrado com sucesso!",
                    Toast.LENGTH_LONG).show();
        }
        dialog.dismiss();
    }

    private void abrirActivity(Class<?> activity) {
        Intent intent = new Intent(LoginActivity.this, activity);
        startActivity(intent);
    }




}