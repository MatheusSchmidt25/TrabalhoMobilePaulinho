package com.example.trabalhomobile.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.trabalhomobile.Global;
import com.example.trabalhomobile.R;
import com.example.trabalhomobile.adapter.NotasListAdapter;
import com.example.trabalhomobile.dao.PedidoDao;
import com.example.trabalhomobile.model.Pedido;

import java.util.ArrayList;

public class NotasActivity extends AppCompatActivity {

    private RecyclerView rvNotas;
    private Context context;
    private Button btVoltar;
    private ArrayList<Pedido> listaNotas;
    String nomeVendedor = Global.nomeVendedor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notas);
        rvNotas = findViewById(R.id.rvNotas);

        btVoltar = findViewById(R.id.btVoltar);

        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                voltar();
            }
        });

        context = this;
        notas();
    }

    private void voltar() {
        finish();
    }

    private void notas() {
        ArrayList<Pedido> listaPedidos = PedidoDao.getInstance(context).getAll();
        listaNotas = new ArrayList<>();
        for (Pedido pedido : listaPedidos){
            if (pedido.getVendedor().equals(nomeVendedor)){
                listaNotas.add(pedido);
            }
        }
            NotasListAdapter adapter = new NotasListAdapter(listaNotas, this);
            rvNotas.setLayoutManager(new LinearLayoutManager(this));
            rvNotas.setAdapter(adapter);

    }
}