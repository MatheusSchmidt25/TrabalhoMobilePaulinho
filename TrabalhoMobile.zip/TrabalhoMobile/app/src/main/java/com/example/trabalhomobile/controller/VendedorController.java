package com.example.trabalhomobile.controller;

import android.content.Context;

import com.example.trabalhomobile.dao.VendedorDao;
import com.example.trabalhomobile.model.Vendedor;

import java.util.ArrayList;

public class VendedorController {

    private Context context;

    public VendedorController(Context context){
        this.context = context;
    }

    public String salvarVendedor(String nome, String cpf, String login, String senha){
        try {
            if(nome.equals("") || nome.isEmpty()){
                return "Informe seu NOME!";
            }
            if (cpf.equals("") || cpf.isEmpty()){
                return "Informe seu CPF!";
            }
            if (login.equals("") || login.isEmpty()){
                return "Informe seu LOGIN";
            }
            if(senha.equals("") || senha.isEmpty()){
                return "Informe sua SENHA!";
            }

            Vendedor vendedor = VendedorDao.getInstancia(context)
                    .getById(Integer.parseInt(cpf));
            if(vendedor != null){
                return "O CPF ("+cpf+") já está cadastrado!";
            }else{
                vendedor = new Vendedor();
                vendedor.setNome(nome);
                vendedor.setCpf(cpf);
                vendedor.setLogin(login);
                vendedor.setSenha(senha);

                VendedorDao.getInstancia(context).insert(vendedor);
            }
        }catch (Exception ex){
            return "Erro ao Gravar Vendedor";
        }
        return  null;
    }
    public ArrayList<Vendedor> retornarTodosVendedores(){
        return VendedorDao.getInstancia(context).getAll();
    }
}
