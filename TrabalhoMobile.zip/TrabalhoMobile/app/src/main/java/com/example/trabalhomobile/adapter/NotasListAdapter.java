package com.example.trabalhomobile.adapter;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.trabalhomobile.R;
import com.example.trabalhomobile.model.Pedido;

import java.util.ArrayList;
public class NotasListAdapter extends RecyclerView.Adapter<NotasListAdapter.ViewHolder> {
    private ArrayList<Pedido> listaPedidos;
    private Context context;

    public NotasListAdapter(ArrayList<Pedido> listaAlunos, Context context) {
        this.listaPedidos = listaAlunos;
        this.context = context;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View listItem = inflater.inflate(R.layout.activity_item_list_nota,
                parent, false);
        return new ViewHolder(listItem);
    }

    /**
     * Método que adiciona os dados de Aluno na tela
     * @param holder The ViewHolder which should be updated to represent the contents of the
     *        item at the given position in the data set.
     * @param position The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Pedido pedidoSelecionado = listaPedidos.get(position);
        holder.tvCliente.setText(String.valueOf(pedidoSelecionado.getCliente()));
        holder.tvMarca.setText(String.valueOf(pedidoSelecionado.getMarca()));
        holder.tvModelo.setText(String.valueOf(pedidoSelecionado.getModelo()));
        holder.tvValor.setText(String.valueOf(pedidoSelecionado.getValor()));
        holder.tvTotal.setText(String.valueOf(pedidoSelecionado.getValor()));
        holder.tvFormaPag.setText(String.valueOf(pedidoSelecionado.getFormaPagamento()));
    }

    /**
     * Retorna a quantidade de elementos contidos na lista
     * @return
     */
    @Override
    public int getItemCount() {
        return this.listaPedidos.size();
    }

    /**Classe que vincula o componente do xml para ser manipulado**/
    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView tvCliente;
        public TextView tvMarca;
        public TextView tvModelo;
        public TextView tvValor;
        public TextView tvTotal;
        public TextView tvFormaPag;



        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            this.tvCliente = itemView.findViewById(R.id.tvCliente);
            this.tvMarca = itemView.findViewById(R.id.tvMarca);
            this.tvModelo = itemView.findViewById(R.id.tvModelo);
            this.tvValor = itemView.findViewById(R.id.tvValor);
            this.tvTotal = itemView.findViewById(R.id.tvTotal);
            this.tvFormaPag = itemView.findViewById(R.id.tvFormaPag);

        }
    }

}
