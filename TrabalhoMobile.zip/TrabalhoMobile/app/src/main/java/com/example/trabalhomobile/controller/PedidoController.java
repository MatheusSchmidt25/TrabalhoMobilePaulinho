package com.example.trabalhomobile.controller;

import android.content.Context;

import com.example.trabalhomobile.dao.PedidoDao;

import java.util.ArrayList;

public class PedidoController {
    private Context context;
    public PedidoController(Context context){
        this.context = context;
    }

    public ArrayList<String> obterNomesProdutos() {
        return PedidoDao.getInstance(context).getNomesProdutos();
    }

}
